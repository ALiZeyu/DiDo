import pydub
from pydub import AudioSegment

# file1 = open('data/3.mp3', "rb")
# song0 = AudioSegment.from_file_using_temporary_files(file1)
AudioSegment.converter ="/usr/bin/ffmpeg"
song1 = AudioSegment.from_mp3('3.mp3')
song2 = AudioSegment.from_mp3('4.mp3')

# pydub.AudioSegment.converter = r"C:\Users\jessezyli\Downloads\ffmpeg-latest-win64-static\bin\ffmpeg.exe"

#AudioSegment.from_file('data/4.mp3',format='mp3')

song3 = song1.overlay(song2);
song3.export('merge.mp3', format="mp3")
